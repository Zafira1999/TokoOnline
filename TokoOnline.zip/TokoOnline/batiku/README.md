# TokoOnlineRKS
TugasRKS

Tugas sesuai dengan gambaran Wirefream namun saya tambahkan halaman baru di luar wireframe
Link wireframe : https://drive.google.com/drive/folders/1dYTxMH6YMl5TmwP4rj0FmBNzbE00CbMi?usp=sharing
Tugas sesuai dengan gambaran Workflow
Link workflow : https://elearning.uad.ac.id/mod/assign/view.php?id=7645
Tugas sesuai dengan dokumentasi kebutuhan
link : https://elearning.uad.ac.id/mod/assign/view.php?id=8718

Maaf pak saya menggunkan DataBase
untuk nama Data Base Batiku

Untuk Admin 
user = admin@admin.com
pass = admin

untuk user
bisa ditambahkan sacara langsung
